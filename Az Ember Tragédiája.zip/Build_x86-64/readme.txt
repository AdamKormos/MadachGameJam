A Hungarian linear boardgame about Imre Madách's The Tragedy of Man. 
Two players take turns, answering questions regarding the writing. Everything is in Hungarian though, but for
proof of concept, you can launch the game with the exe file named "Az Ember Tragédiája".
Press [Enter] to start a round, making the tutorial text disappear.